// hub380-admin.js
// Simple JS functionality for the hub380 admin page
jQuery(document).ready(function($) {
    // Example: log message in console
    console.log('hub380 admin script loaded');
});
