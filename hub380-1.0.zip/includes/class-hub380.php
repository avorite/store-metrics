<?php
/**
 * Main class for hub380 Plugin.
 *
 * @package hub380
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Hub380' ) ) :

class Hub380 {

	/**
	 * Hook suffix for admin page.
	 *
	 * @var string
	 */
	private $hook_suffix = '';

	/**
	 * Constructor.
	 *
	 * We hook our initialization to 'plugins_loaded' so that WooCommerce has time to load.
	 */
	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init_plugin' ), 11 );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	/**
	 * Initialize plugin functionality after all plugins have loaded.
	 */
	public function init_plugin() {
		// Check if WooCommerce is active by testing for WC_VERSION constant.
		if ( ! defined( 'WC_VERSION' ) ) {
			add_action( 'admin_notices', array( $this, 'woocommerce_inactive_notice' ) );
			return;
		}

		// Load translation files.
		$this->load_textdomain();

		// Register admin menu.
		$this->register_admin_menu();

		// Enqueue admin assets.
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );

		// Register admin_post action for refresh.
		add_action( 'admin_post_hub380_refresh', array( $this, 'handle_refresh_stats' ) );
	}

	/**
	 * Display notice if WooCommerce is not active.
	 */
	public function woocommerce_inactive_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		$woocommerce_path = 'woocommerce/woocommerce.php';
		$is_woocommerce_installed = file_exists( WP_PLUGIN_DIR . '/' . $woocommerce_path );

		if ( $is_woocommerce_installed ) {
			$action_url = wp_nonce_url( 
				add_query_arg(
					array(
						'action' => 'activate',
						'plugin' => $woocommerce_path
					),
					admin_url( 'plugins.php' )
				),
				'activate-plugin_' . $woocommerce_path
			);
			$message = sprintf(
				/* translators: %1$s: Plugin name, %2$s: WooCommerce activation link */
				esc_html__( '%1$s requires WooCommerce to be active. Please %2$s.', 'hub380' ),
				'<strong>Hub380</strong>',
				'<a href="' . esc_url( $action_url ) . '">' . esc_html__( 'activate WooCommerce', 'hub380' ) . '</a>'
			);
		} else {
			$action_url = wp_nonce_url(
				add_query_arg(
					array(
						'action' => 'install-plugin',
						'plugin' => 'woocommerce'
					),
					admin_url( 'update.php' )
				),
				'install-plugin_woocommerce'
			);
			$message = sprintf(
				/* translators: %1$s: Plugin name, %2$s: WooCommerce installation link */
				esc_html__( '%1$s requires WooCommerce to be installed and active. Please %2$s.', 'hub380' ),
				'<strong>Hub380</strong>',
				'<a href="' . esc_url( $action_url ) . '">' . esc_html__( 'install WooCommerce', 'hub380' ) . '</a>'
			);
		}

		echo '<div class="notice notice-error"><p>' . wp_kses_post( $message ) . '</p></div>';
	}

	/**
	 * Load plugin text domain.
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'hub380', false, dirname( plugin_basename( __FILE__ ) ) . '/../languages' );
	}

	/**
	 * Register admin menu page.
	 */
	public function register_admin_menu() {
		$this->hook_suffix = add_menu_page(
			esc_html__( 'Store Statistics', 'hub380' ),
			esc_html__( 'Store Stats', 'hub380' ),
			'manage_options',
			'hub380',
			array( $this, 'admin_page_callback' ),
			'dashicons-chart-area',
			26
		);
	}

	/**
	 * Enqueue admin CSS and JS files.
	 *
	 * @param string $hook The current admin page hook.
	 */
	public function enqueue_admin_assets( $hook ) {
		// Load assets only on our plugin admin page.
		if ( $hook !== $this->hook_suffix ) {
			return;
		}

		wp_enqueue_style(
			'hub380-admin-style',
			plugin_dir_url( __FILE__ ) . '../admin/css/hub380-admin.css',
			array(),
			'1.0.0'
		);

		wp_enqueue_script(
			'hub380-admin-script',
			plugin_dir_url( __FILE__ ) . '../admin/js/hub380-admin.js',
			array( 'jquery' ),
			'1.0.0',
			true
		);
	}

	/**
	 * Callback function for admin page.
	 */
	public function admin_page_callback() {
		$popular_product = $this->get_most_popular_product();
		$total_sales     = $this->get_total_sales();
		$total_deals     = $this->get_total_deals();
		$roi             = $this->calculate_roi( $total_sales );

		// Check for admin notice
		$notice = ( isset( $_GET['hub380_notice'] ) ) ? sanitize_text_field( wp_unslash( $_GET['hub380_notice'] ) ) : '';
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Store Statistics', 'hub380' ); ?></h1>
			
			<?php if ( ! empty( $notice ) ) : ?>
				<div class="notice notice-success is-dismissible">
					<p><?php echo esc_html( $notice ); ?></p>
				</div>
			<?php endif; ?>

			<!-- Settings Form -->
			<form method="post" action="options.php">
				<?php
				settings_fields( 'hub380_options' );
				do_settings_sections( 'hub380' );
				submit_button( esc_html__( 'Save Settings', 'hub380' ) );
				?>
			</form>

			<hr />

			<!-- Statistics Table -->
			<h2><?php esc_html_e( 'Current Statistics', 'hub380' ); ?></h2>
			<table class="widefat fixed" cellspacing="0">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Metric', 'hub380' ); ?></th>
						<th><?php esc_html_e( 'Value', 'hub380' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><?php esc_html_e( 'Most Popular Product', 'hub380' ); ?></td>
						<td><?php echo esc_html( $popular_product ); ?></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'Total Sales', 'hub380' ); ?></td>
						<td><?php echo wc_price( $total_sales ); ?></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'Total Deals', 'hub380' ); ?></td>
						<td><?php echo esc_html( $total_deals ); ?></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'ROI', 'hub380' ); ?></td>
						<td><?php echo esc_html( $roi ); ?></td>
					</tr>
				</tbody>
			</table>

			<!-- Refresh Statistics Form -->
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="hub380-refresh-form">
				<?php wp_nonce_field( 'hub380_refresh_action', 'hub380_nonce' ); ?>
				<input type="hidden" name="action" value="hub380_refresh">
				<p>
					<input type="submit" class="button button-primary" value="<?php esc_attr_e( 'Refresh Statistics', 'hub380' ); ?>">
				</p>
			</form>
		</div>
		<?php
	}

	/**
	 * Handle refresh statistics action.
	 *
	 * This function verifies the nonce and redirects back with a notice.
	 */
	public function handle_refresh_stats() {
		// Verify nonce.
		if ( ! isset( $_POST['hub380_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hub380_nonce'] ) ), 'hub380_refresh_action' ) ) {
			wp_die( esc_html__( 'Nonce verification failed', 'hub380' ) );
		}

		// Additional actions to refresh statistics can be added here.
		$redirect_url = add_query_arg(
			array(
				'hub380_notice' => esc_attr__( 'Statistics refreshed successfully!', 'hub380' ),
			),
			admin_url( 'admin.php?page=hub380' )
		);
		wp_safe_redirect( $redirect_url );
		exit;
	}

	/**
	 * Get the most popular product based on total sales meta.
	 *
	 * @return string
	 */
	private function get_most_popular_product() {
		$args = array(
			'post_type'      => 'product',
			'meta_key'       => 'total_sales',
			'orderby'        => 'meta_value_num',
			'posts_per_page' => 1,
		);
		$products = get_posts( $args );
		if ( ! empty( $products ) ) {
			$product = wc_get_product( absint( $products[0]->ID ) );
			if ( $product ) {
				return $product->get_name();
			}
		}
		return esc_html__( 'No product found', 'hub380' );
	}

	/**
	 * Get array of valid order statuses for statistics
	 *
	 * @return array
	 */
	private function get_valid_order_statuses() {
		return array(
			'wc-completed',
			'wc-processing',
			'wc-on-hold'
		);
	}

	/**
	 * Get total sales from valid orders.
	 *
	 * @return float
	 */
	private function get_total_sales() {
		$args = array(
			'limit'  => -1,
			'status' => $this->get_valid_order_statuses(),
			'return' => 'ids',
		);
		$order_ids  = wc_get_orders( $args );
		$total_sales = 0;
		foreach ( $order_ids as $order_id ) {
			$order = wc_get_order( absint( $order_id ) );
			if ( $order ) {
				$total_sales += floatval( $order->get_total() );
			}
		}
		return $total_sales;
	}

	/**
	 * Get total number of valid orders.
	 *
	 * @return int
	 */
	private function get_total_deals() {
		$args = array(
			'limit'  => -1,
			'status' => $this->get_valid_order_statuses(),
			'return' => 'ids',
		);
		$order_ids = wc_get_orders( $args );
		return count( $order_ids );
	}

	/**
	 * Get total cost price from all valid order items.
	 *
	 * This function iterates over completed orders and sums up:
	 * (Cost price per product * quantity).
	 *
	 * Cost price is retrieved from product meta '_wc_cog_cost'.
	 * If not set, a default value of 5 is used.
	 *
	 * @return float
	 */
	private function get_total_cost_price() {
		$args = array(
			'limit'  => -1,
			'status' => $this->get_valid_order_statuses(),
			'return' => 'ids',
		);
		$order_ids  = wc_get_orders( $args );
		$total_cost = 0;
		foreach ( $order_ids as $order_id ) {
			$order = wc_get_order( absint( $order_id ) );
			foreach ( $order->get_items() as $item ) {
				$product_id = absint( $item->get_product_id() );
				$cost       = get_post_meta( $product_id, '_wc_cog_cost', true );
				// If cost is not set, fallback to default value.
				$cost     = ( $cost ) ? floatval( $cost ) : 5;
				$quantity = absint( $item->get_quantity() );
				$total_cost += $cost * $quantity;
			}
		}
		return $total_cost;
	}

	/**
	 * Register plugin settings
	 */
	public function register_settings() {
		register_setting( 'hub380_options', 'hub380_pr_budget', 'floatval' );
		register_setting( 'hub380_options', 'hub380_default_cost_price', 'floatval' );
		
		add_settings_section(
			'hub380_settings_section',
			esc_html__( 'ROI Settings', 'hub380' ),
			null,
			'hub380'
		);

		add_settings_field(
			'hub380_pr_budget',
			esc_html__( 'PR Budget', 'hub380' ),
			array( $this, 'pr_budget_callback' ),
			'hub380',
			'hub380_settings_section'
		);

		add_settings_field(
			'hub380_default_cost_price',
			esc_html__( 'Cost Price', 'hub380' ),
			array( $this, 'cost_price_callback' ),
			'hub380',
			'hub380_settings_section'
		);
	}

	/**
	 * Callback for PR budget field
	 */
	public function pr_budget_callback() {
		$pr_budget = get_option( 'hub380_pr_budget', 0 );
		echo '<input type="number" step="0.01" name="hub380_pr_budget" value="' . esc_attr( $pr_budget ) . '" />';
	}

	/**
	 * Callback for cost price field
	 */
	public function cost_price_callback() {
		$cost_price = get_option( 'hub380_default_cost_price', 0 );
		echo '<input type="number" step="0.01" name="hub380_default_cost_price" value="' . esc_attr( $cost_price ) . '" />';
	}

	/**
	 * Calculate ROI based on total sales, cost price and PR budget
	 *
	 * @param float $total_sales Total sales amount
	 * @return string Formatted ROI percentage
	 */
	private function calculate_roi( $total_sales ) {
		$pr_budget = floatval( get_option( 'hub380_pr_budget', 0 ) );
		$cost_price = floatval( get_option( 'hub380_default_cost_price', 0 ) );
		$total_deals = $this->get_total_deals();
		
		$total_cost_price = $cost_price * $total_deals;
		$investment = $pr_budget + $total_cost_price;
		
		if ( $investment <= 0 ) {
			return '0%';
		}
		
		$roi = ( $total_sales - $investment ) / $investment;
		return number_format( $roi * 100, 2 ) . '%';
	}
}

endif;
